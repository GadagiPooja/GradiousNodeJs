// config/db.config.js
module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "Gadagi@123",
    DB: "bill_management"
  };
  