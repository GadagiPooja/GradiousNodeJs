// models/bill.model.js
const mysql = require("mysql2");
const dbConfig = require("./../configs/db.config");

const connection = mysql.createConnection({
  host: dbConfig.HOST,
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  database: dbConfig.DB,
});

connection.connect((error) => {
  if (error) throw error;
  console.log("Successfully connected to the database.");
});

const Bill = {};

Bill.getAll = (result) => {
  connection.query("SELECT * FROM bills", (error, res) => {
    if (error) {
      console.log("error: ", error);
      result(error, null);
      return;
    }

    result(null, res);
  });
};

Bill.getById = (id, result) => {
  connection.query("SELECT * FROM bills WHERE id = ?", [id], (error, res) => {
    if (error) {
      console.log("error: ", error);
      result(error, null);
      return;
    }

    if (res.length) {
      result(null, res[0]);
      return;
    }

    result({ kind: "not_found" }, null);
  });
};

Bill.create = (newBill, result) => {
  connection.query("INSERT INTO bills SET ?", newBill, (error, res) => {
    if (error) {
      console.log("error: ", error);
      result(error, null);
      return;
    }

    result(null, { id: res.insertId, ...newBill });
  });
};

Bill.updateById = (id, bill, result) => {
  connection.query(
    "UPDATE bills SET bill_number = ?, customer_id = ?, bill_date = ?, amount = ?, status = ?, payment_due_date = ?, payment_method = ? WHERE id = ?",
    [bill.bill_number, bill.customer_id, bill.bill_date, bill.amount, bill.status, bill.payment_due_date, bill.payment_method, id],
    (error, res) => {
      if (error) {
        console.log("error: ", error);
        result(error, null);
        return;
      }

      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }

      result(null, { id: id, ...bill });
    }
  );
};

Bill.remove = (id, result) => {
  connection.query("DELETE FROM bills WHERE id = ?", id, (error, res) => {
    if (error) {
      console.log("error: ", error);
      result(error, null);
      return;
    }

    if (res.affectedRows == 0) {
      result({ kind: "not_found" }, null);
      return;
    }

    result(null, res);
  });
};

module.exports = Bill;
