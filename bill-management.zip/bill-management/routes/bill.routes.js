// routes/bill.routes.js
module.exports = (app) => {
    const bills = require("../controllers/bill.controller");
  
    app.get("/bills", bills.findAll);
  
    app.get("/bills/:id", bills.findOne);
  
    app.post("/bills", bills.create);
  
    app.put("/bills/:id", bills.update);
  
    app.delete("/bills/:id", bills.delete);
  };
  