	1. Create Table
CREATE TABLE bills (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bill_number VARCHAR(50) NOT NULL,
    customer_id INT NOT NULL,
    bill_date DATE NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) NOT NULL,
    payment_due_date DATE NOT NULL,
    payment_method VARCHAR(50) NOT NULL
);

2. Insert Data
INSERT INTO bills (bill_number, customer_id, bill_date, amount, status, payment_due_date, payment_method)
VALUES
('B1001', 1, '2024-08-01', 500.00, 'Pending', '2024-08-15', 'Credit Card'),
('B1002', 2, '2024-08-03', 1200.00, 'Paid', '2024-08-10', 'Bank Transfer'),
('B1003', 3, '2024-08-05', 750.00, 'Pending', '2024-08-20', 'Cash');


3. Retrieve All Data
SELECT * FROM bills;


4. Retrieve a Specific Bill by ID
SELECT * FROM bills WHERE id = 1;


5. Update a Bill's Status
UPDATE bills
SET status = 'Paid'
WHERE id = 1;


6. Delete a Bill
DELETE FROM bills WHERE id = 3;


7. Retrieve Bills with a Pending Status
SELECT * FROM bills WHERE status = 'Pending';


8. Retrieve Bills Due by a Specific Date
SELECT * FROM bills WHERE payment_due_date <= '2024-08-15';


9. Sum of Amounts for All Bills
SELECT SUM(amount) AS total_amount FROM bills;


10. Count Bills by Payment Method
SELECT payment_method, COUNT(*) AS total_bills
FROM bills
GROUP BY payment_method;