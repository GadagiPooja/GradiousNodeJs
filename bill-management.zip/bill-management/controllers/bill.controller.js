// controllers/bill.controller.js
const Bill = require("../models/bill.model");

exports.findAll = (req, res) => {
  Bill.getAll((error, data) => {
    if (error)
      res.status(500).send({
        message: error.message || "Some error occurred while retrieving bills.",
      });
    else res.send(data);
  });
};

exports.findOne = (req, res) => {
  Bill.getById(req.params.id, (error, data) => {
    if (error) {
      if (error.kind === "not_found") {
        res.status(404).send({
          message: `Not found Bill with id ${req.params.id}.`,
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Bill with id " + req.params.id,
        });
      }
    } else res.send(data);
  });
};

exports.create = (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!",
    });
  }

  const bill = {
    bill_number: req.body.bill_number,
    customer_id: req.body.customer_id,
    bill_date: req.body.bill_date,
    amount: req.body.amount,
    status: req.body.status,
    payment_due_date: req.body.payment_due_date,
    payment_method: req.body.payment_method,
  };

  Bill.create(bill, (error, data) => {
    if (error)
      res.status(500).send({
        message: error.message || "Some error occurred while creating the Bill.",
      });
    else res.send(data);
  });
};

exports.update = (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!",
    });
  }

  Bill.updateById(req.params.id, new Bill(req.body), (error, data) => {
    if (error) {
      if (error.kind === "not_found") {
        res.status(404).send({
          message: `Not found Bill with id ${req.params.id}.`,
        });
      } else {
        res.status(500).send({
          message: "Error updating Bill with id " + req.params.id,
        });
      }
    } else res.send(data);
  });
};

exports.delete = (req, res) => {
  Bill.remove(req.params.id, (error, data) => {
    if (error) {
      if (error.kind === "not_found") {
        res.status(404).send({
          message: `Not found Bill with id ${req.params.id}.`,
        });
      } else {
        res.status(500).send({
          message: "Could not delete Bill with id " + req.params.id,
        });
      }
    } else res.send({ message: `Bill was deleted successfully!` });
  });
};
